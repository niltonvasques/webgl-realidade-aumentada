// A biblioteca Aruco detecta os markers e atribui um id único de acordo
// com o desenho do marker.
// Aqui ficará declarado todos os marcadores que iremos utilizar na aplicação.
//
var SolMarker 		= new Object();
SolMarker.id		= 25;
SolMarker.rotMat 	= new Matrix4( );
SolMarker.transMat 	= new Matrix4( );
SolMarker.scaleMat 	= new Matrix4( );
SolMarker.modelMat 	= new Matrix4( );
SolMarker.mvpMat 	= new Matrix4( );
SolMarker.lightColor	= new Vector4( );
SolMarker.color		= new Vector3( );
SolMarker.modelSize	= 90.0;

function updateSolMarker( markerId, pose ){
		
	if( markerId != SolMarker.id ){
		return;
	}

	yaw 	= Math.atan2(pose.bestRotation[0][2], pose.bestRotation[2][2]) * 180.0/Math.PI;
	pitch 	= -Math.asin(-pose.bestRotation[1][2]) * 180.0/Math.PI;
	roll 	= Math.atan2(pose.bestRotation[1][0], pose.bestRotation[1][1]) * 180.0/Math.PI;

	SolMarker.found = true;

	SolMarker.rotMat.setIdentity();
	SolMarker.rotMat.rotate(yaw, 0.0, 1.0, 0.0);
	SolMarker.rotMat.rotate(pitch, 1.0, 0.0, 0.0);
	SolMarker.rotMat.rotate(roll, 0.0, 0.0, 1.0);

	SolMarker.transMat.setIdentity();
	SolMarker.transMat.translate(pose.bestTranslation[0], pose.bestTranslation[1], -pose.bestTranslation[2]);

	SolMarker.scaleMat.setIdentity();
	SolMarker.scaleMat.scale( SolMarker.modelSize, SolMarker.modelSize, SolMarker.modelSize );

	/*console.log(yaw);
	console.log(pitch);
	console.log(roll);
	*/

	/*console.log("pose.bestTranslation.x = " + pose.bestTranslation[0]/262.144);
	console.log("pose.bestTranslation.y = " + pose.bestTranslation[1]/262.144);
	console.log("pose.bestTranslation.z = " + -pose.bestTranslation[2]/262.144);
	*/
}


function drawSol( axisEnabled ){
	if( !SolMarker.found ) return;

	SolMarker.modelMat.setIdentity();
	SolMarker.modelMat.multiply(SolMarker.transMat);
	SolMarker.modelMat.multiply(SolMarker.rotMat);
	SolMarker.modelMat.multiply(SolMarker.scaleMat);

	SolMarker.mvpMat.setIdentity( );
	SolMarker.mvpMat.multiply( scene.projMat );
	SolMarker.mvpMat.multiply( scene.viewMat );
	SolMarker.mvpMat.multiply( SolMarker.modelMat );
	
	if( axisEnabled ) drawAxis(axis, shaderAxis, SolMarker.mvpMat);

	try { 
		gl.useProgram( shaderPlanets );
	}catch(err){
		alert( err );
		console.error( err.description );
	}
	
	gl.uniformMatrix4fv( shaderPlanets.uModelMat, false, SolMarker.mvpMat.elements );

	SolMarker.color.elements[0] = 1.0; 
	SolMarker.color.elements[1] = 1.0; 
	SolMarker.color.elements[2] = 0.0;
	gl.uniform3fv(shaderPlanets.uColor, SolMarker.color.elements);


	for(var o = 0; o < sphereObj.model.length; o++) { 
		draw(sphereObj.model[o], shaderPlanets, gl.TRIANGLES);
	}
}
